/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorphisme;

/**
 *
 * @author LENOVO
 */
public class pegawai {
    String nama;
    int gaji;
    pegawai(){
        
    }
    pegawai (String nm){
        this.nama=nm;
        System.out.println("Pegawai");
    }
    public int gaji(){
        return 0;
    }
}
