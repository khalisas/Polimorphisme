/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorphisme;

import javafx.scene.Parent;

/**
 *
 * @author LENOVO
 */
public class Child extends Parent {
    int x = 10;
    public void Info(){
        System.out.println("ini class child");
    }
    
}
