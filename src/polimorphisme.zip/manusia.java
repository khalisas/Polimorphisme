/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorphisme;

/**
 *
 * @author LENOVO
 */
public class manusia {
    void makan(){
        System.out.println("manusia makan");
    }
    void tidur(){
        System.out.println("manusia tidur");
    }
    void bergerak(){
        System.out.println("manusia bergerak");
    }
    
}
